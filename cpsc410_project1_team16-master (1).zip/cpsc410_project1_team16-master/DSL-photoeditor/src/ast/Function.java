package ast;

import libs.Node;

import java.util.List;

public abstract class Function extends Node {

}
